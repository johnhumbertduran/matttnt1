$(function() {
    // Prevent Bootstrap modal from scrolling to the top when interacting with the datepicker
    $(document).on('focusin', function(e) {
        if ($(e.target).closest(".ui-datepicker").length) {
            e.stopImmediatePropagation(); // Prevent Bootstrap from hijacking the focus and causing scroll issues
        }
    });

    // Initialize the datepicker for fully booked dates with multi-date selection support
    var fullyBookedDates = []; // Array to store the fully booked dates

    $('#edit_fully_booked_dates').datepicker({
        dateFormat: 'yy-mm-dd',
        beforeShowDay: function(date) {
            const dateString = $.datepicker.formatDate('yy-mm-dd', date);
            // Disable the dates that are already fully booked
            if (fullyBookedDates.includes(dateString)) {
                return [false, 'disabled-date', 'Already Fully Booked']; // Disable fully booked dates
            }
            return [true]; // All other dates are selectable
        },
        onSelect: function(dateText) {
            // Toggle the selection of dates (Add or Remove from the fullyBookedDates array)
            if (fullyBookedDates.includes(dateText)) {
                fullyBookedDates = fullyBookedDates.filter(date => date !== dateText); // Remove selected date
            } else {
                fullyBookedDates.push(dateText); // Add selected date
            }

            // Update the input field with the selected dates
            $('#edit_fully_booked_dates').val(fullyBookedDates.join(','));
        }
    });

    // Function to populate the modal with hotel data
    window.openEditModal = function(hotel) {
        $('#edit_hotel_id').val(hotel.id);
        $('#edit_hotel_name').val(hotel.name);
        $('#edit_price_adult').val(hotel.price_adult);
        $('#edit_price_kid').val(hotel.price_kid);
        $('#edit_check_in').val(hotel.check_in);
        $('#edit_check_out').val(hotel.check_out);
        $('#edit_capacity').val(hotel.capacity);
        $('#edit_description').val(hotel.description);
        $('#edit_image_url').val(hotel.image_url);
        $('#edit_inclusions').val(hotel.inclusions);
        $('#edit_exclusions').val(hotel.exclusions);
        $('#edit_policy').val(hotel.policy);

        // Set the fully booked dates and refresh the datepicker
        fullyBookedDates = hotel.fully_booked_dates ? hotel.fully_booked_dates.split(',') : [];
        $('#edit_fully_booked_dates').val(fullyBookedDates.join(','));
        $('#edit_fully_booked_dates').datepicker('refresh'); // Refresh the datepicker to show disabled dates

        // Set features checkboxes
        $('#edit_feature_wifi').prop('checked', hotel.features.includes('Free Wifi'));
        $('#edit_feature_breakfast').prop('checked', hotel.features.includes('Free Breakfast'));
        $('#edit_feature_pool').prop('checked', hotel.features.includes('Swimming Pool'));
        $('#edit_feature_pet').prop('checked', hotel.features.includes('Pet Friendly'));
        $('#edit_feature_non_beachfront').prop('checked', hotel.features.includes('Non Beachfront'));
        $('#edit_feature_beachfront').prop('checked', hotel.features.includes('Beachfront'));
        $('#edit_feature_kitchen').prop('checked', hotel.features.includes('With Kitchen'));
        $('#edit_feature_grilling_area').prop('checked', hotel.features.includes('With Grilling Area'));
        $('#edit_feature_non_smoking').prop('checked', hotel.features.includes('Non Smoking'));
        $('#edit_feature_double_bed').prop('checked', hotel.features.includes('Double Sized Bed'));

        // Show the modal
        var editHotelModal = new bootstrap.Modal(document.getElementById('editHotelModal'));
        editHotelModal.show();
    };

    // Handle form submission to update hotel via AJAX
    $('#editHotelForm').submit(function(e) {
        e.preventDefault(); // Prevent form submission

        var formData = $(this).serialize(); // Serialize form data
        $.post('edit_hotel_handler.php', formData, function(response) {
            // Handle the response
            if (response.success) {
                location.reload(); // Reload page
            } else {
                alert('Error updating hotel: ' + response.error);
            }
        }, 'json');
    });
});
