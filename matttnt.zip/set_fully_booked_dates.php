<?php
include 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = $_POST['product_id'];   // Get the product ID
    $category = $_POST['category'];       // Get the category (e.g., hotels, meals, etc.)
    $fully_booked_dates = $_POST['fully_booked_dates']; // Get the comma-separated dates

    // Break down the dates into an array
    $datesArray = explode(',', $fully_booked_dates);

    // Prepare the insert statement
    $sql = "INSERT INTO fully_booked_dates (product_id, category, booked_date) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);

    foreach ($datesArray as $date) {
        $date = trim($date); // Clean up any extra spaces
        $stmt->bind_param('iss', $product_id, $category, $date);
        $stmt->execute();
    }

    // Redirect back to the dashboard after insertion
    header("Location: admin_dashboard.php?section=$category");
    exit();
}

// Close the database connection
$conn->close();
?>
