<?php
session_start();
include 'db_connection.php';

$error_message = ''; 
$success_message = ''; 

// Check if redirected after registration
if (isset($_GET['registration']) && $_GET['registration'] == 'success') {
    $success_message = 'Registration successful! Please log in.';
}

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Fetch the user from the database
    $sql = "SELECT * FROM users WHERE username='$username' OR email='$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Verify password
        if (password_verify($password, $row['password'])) {
            $_SESSION['username'] = $row['username'];

            // Check the role and redirect accordingly
            if ($row['role'] == 'admin') {
                header("Location: admin_dashboard.php");
            } else {
                header("Location: dashboard.php");
            }
            exit();
        } else {
            $error_message = 'Invalid password!';
        }
    } else {
        $error_message = 'User not found!';
    }
}

$conn->close();
?>


    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Matt Travel and Tours</title>

        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
        <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&family=Roboto:wght@400;500&display=swap" rel="stylesheet">

        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

        <!-- Font Awesome for Icons -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

        <style>
    body, html {
        font-family: 'Roboto', sans-serif;
        height: 100%;
        margin: 0;
        padding: 0;
    }

    h2, h3 {
        font-family: 'Montserrat', sans-serif;
    }

    .hero {
        background: url('/matttnt/images/beach/1.jpg') no-repeat center center;
        background-size: cover;
        height: 100vh;
        display: flex;
        justify-content: space-between;
        align-items: center;
        color: white;
        padding: 20px;
        position: relative;
    }

    .hero p {
        font-size: 1.25rem; /* Reduce paragraph font size */
    }

    .hero .cta {
        margin-top: 20px;
    }

    /* Updated login box styling */
    .login-box {
        background-color: rgba(255, 255, 255, 0.95); /* Keep background opaque for readability */
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        width: 320px;
        position: absolute;
        right: 50px;
        top: 25%;
    }

    .login-box h3 {
        font-family: 'Montserrat', sans-serif; /* New modern font for heading */
        font-size: 1.7rem;
        margin-bottom: 15px;
        text-align: center;
        color: #333;
        text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.1);
    }

    .login-box .form-label {
        font-family: 'Roboto', sans-serif; /* New font for labels */
        font-size: 1rem; 
        color: #333;
    }

    .login-box .form-control {
        font-family: 'Roboto', sans-serif;
        font-size: 1rem;
        padding: 10px;
    }

    .login-box .btn-primary {
        font-family: 'Roboto', sans-serif;
        background-color: #4ABDAC;
        border: none;
        font-size: 1rem;
        padding: 10px 0;
        text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.1);
    }

    .login-box .btn-primary:hover {
        background-color: #037D77;
    }

    /* Styles for "Don't have an account?" */
    .login-box p {
        font-family: 'Roboto', sans-serif; /* New font for better readability */
        font-size: 1rem; /* Increase the size slightly */
        text-align: center;
        color: #333; /* Darker text for better contrast */
    }

    .login-box a {
        color: #037D77;
        font-weight: 500;
        text-decoration: underline; /* Make the link more visible */
    }

    .login-box a:hover {
        color: #025b5a;
    }

    /* Error message styling */
    .alert {
        font-family: 'Roboto', sans-serif;
        font-size: 0.9rem;
        text-align: center;
        color: #d9534f;
    }

    /* Hide the register form by default */
        #register-form {
            display: none;
        }

    /* Navigation Styling */
    .navbar {
        position: absolute;
        top: 0;
        width: 100%;
        z-index: 10;
        padding: 20px 50px;
        background-color: transparent !important;
    }

    .navbar-brand img {
        width: 75px; /* Adjust logo size */
    }

    .navbar-nav .nav-link {
        color: #fff !important;
        font-size: 14px; /* Reduced nav link font size */
        font-weight: 500;
        transition: color 0.3s ease;
    }

    .navbar-nav .nav-link:hover {
        color: #f2e86d !important;
    }

    .navbar-toggler {
        border: none;
        color: #fff;
    }

    .navbar-collapse {
        justify-content: flex-end;
    }
    .alert-success {
    color: #155724 !important; /* Bootstrap's default green text color */
}
 .register-link {
        cursor: pointer; /* Changes the cursor to pointer */
        color: #037D77; /* Link color */
        font-weight: 500;
        text-decoration: underline; /* Makes the link visible */
    }

    .register-link:hover {
        color: #025b5a; /* Change color on hover */
    }
        @media (max-width: 576px) {
            .hero {
                padding: 20px;
            }
            .navbar-brand img {
                width: 60px; /* Adjust logo size on small devices */
            }
            .navbar-nav .nav-link {
                font-size: 12px;
            }
        }


        </style>
    </head>
    <body>

        <!-- Updated Navigation Bar with Logo -->
        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <img src="/matttnt/images/mattlogo.jpg" alt="Matt Travel and Tours "> <!-- Replace with your logo path -->
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item"><a class="nav-link" href="#">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="#features">Features</a></li>
                        <li class="nav-item"><a class="nav-link" href="#reviews">Reviews</a></li>
                        <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- Hero Section -->
        <section class="hero">
       
        <div class="login-box" id="login-box">
            <!-- Login Form -->
    <form id="login-form" action="index.php" method="POST">
        <h3>Login</h3>

        <!-- Success message display -->
        <?php if ($success_message != ''): ?>
            <div class="alert alert-success"><?php echo $success_message; ?></div>
        <?php endif; ?>

        <!-- Error message display -->
        <?php if ($error_message != ''): ?>
            <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php endif; ?>

        <div class="mb-3">
            <label for="username" class="form-label">Username or Email</label>
            <input type="text" class="form-control" id="username" name="username" required>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>
        <button type="submit" name="login" class="btn btn-primary w-100">Login</button>
         <p class="mt-3">Don't have an account? <a class="register-link" onclick="toggleForms()">Register here</a>.</p>
    </form>

            <!-- Register Form -->
            <form id="register-form" action="register.php" method="POST">
                <h3>Register</h3>
                <div class="mb-3">
                    <label for="reg-username" class="form-label">Username</label>
                    <input type="text" class="form-control" id="reg-username" name="username" required>
                </div>
                <div class="mb-3">
                    <label for="reg-email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="reg-email" name="email" required>
                </div>
                <div class="mb-3">
                    <label for="reg-password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="reg-password" name="password" required>
                </div>
                <button type="submit" name="submit" class="btn btn-primary w-100">Register</button>
                <p class="mt-3">Already have an account? <a onclick="toggleForms()">Login here</a>.</p>
    
                </div>
            </form>
        </div>
    </section>

        <!-- Features/Discovery Section -->
        <section class="features" id="features">
            <div class="container">
                <h2 class="section-title">Explore Puerto Galera</h2>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <img src="/matttnt/images/beach/2.jpg" class="card-img-top" alt="Outward Bound">
                            <div class="card-body">
                                <h5 class="card-title">Snorkeling Tour</h5>
                                <p class="card-text">Explore the wild with our adventure packages.</p>
                                <a href="#" class="btn btn-primary">Explore More</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                            <img src="/matttnt/images/beach/3.jpg" class="card-img-top" alt="Culture Curious">
                            <div class="card-body">
                                <h5 class="card-title">Island Hopping Tour</h5>
                                <p class="card-text">Discover discover beach destinations.</p>
                                <a href="#" class="btn btn-primary">Explore More</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                            <img src="/matttnt/images/beach/4.jpg" class="card-img-top" alt="Relax & Release">
                            <div class="card-body">
                                <h5 class="card-title">Inland Tour</h5>
                                <p class="card-text">Take a break and unwind with our relaxation packages.</p>
                                <a href="#" class="btn btn-primary">Explore More</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Reviews Section -->
        <section class="reviews bg-light" id="reviews">
            <div class="container">
                <h2 class="section-title">What Our Customers Say</h2>
                <div class="row">
                    <div class="col-md-4 review-item">
                        <p>"Matt Travel and Tours made my dream vacation a reality. Their service is top-notch!"</p>
                        <small>- Jessica L.</small>
                    </div>
                    <div class="col-md-4 review-item">
                        <p>"Highly recommend their packages. Everything was smooth and easy."</p>
                        <                    <small>- Robert K.</small>
                    </div>
                    <div class="col-md-4 review-item">
                        <p>"Amazing destinations, fantastic service. Will definitely book again."</p>
                        <small>- Emily R.</small>
                    </div>
                </div>
            </div>
        </section>

        <!-- Contact Section -->
        <section class="contact" id="contact">
            <div class="container">
                <h2 class="section-title">Get in Touch</h2>
                <form class="contact-form">
                    <div class="mb-3">
                        <label for="name" class="form-label">Your Name</label>
                        <input type="text" class="form-control" id="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Your Email</label>
                        <input type="email" class="form-control" id="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="message" class="form-label">Message</label>
                        <textarea class="form-control" id="message" rows="3" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Send Message</button>
                </form>
            </div>
        </section>
        <script>
             
        function toggleForms() {
            var loginForm = document.getElementById('login-form');
            var registerForm = document.getElementById('register-form');

            if (loginForm.style.display === 'none') {
                loginForm.style.display = 'block';
                registerForm.style.display = 'none';
            } else {
                loginForm.style.display = 'none';
                registerForm.style.display = 'block';
            }
        }
    

        </script>
        <!-- Footer -->
        <footer class="bg-dark text-white text-center py-3">
            <div class="container">
                <p>&copy; 2024 Matt Travel and Tours. All rights reserved.</p>
                <div class="social-icons">
                    <a href="#" class="text-white me-2"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="text-white me-2"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="text-white"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
        </footer>

        <!-- Bootstrap JS -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>

