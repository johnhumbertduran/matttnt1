<?php
// processBooking.php
header('Content-Type: application/json');

// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "matttnt";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Database connection failed: ' . $conn->connect_error]));
}

// Get the raw POST data (JSON)
$rawData = file_get_contents('php://input');
$data = json_decode($rawData, true);

// Extract user details
$username = $data['username'];
$email = $data['email'];
$contact_number = $data['contact_number'];
$cartSummary = $data['cartSummary']; // Array of booking items

// Prepare SQL statement for inserting data into bookings table
$stmt = $conn->prepare("INSERT INTO bookings (username, email, contact_number, product_name, check_in_date, check_out_date, nights, rooms, adults, kids, total_price) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

if (!$stmt) {
    echo json_encode(['success' => false, 'message' => 'Failed to prepare statement: ' . $conn->error]);
    exit();
}

// Insert each item from the cart summary into the database
foreach ($cartSummary as $item) {
    $stmt->bind_param(
        "ssssssiiiii", 
        $username, 
        $email, 
        $contact_number, 
        $item['productName'], 
        $item['checkInDate'], 
        $item['checkOutDate'], 
        $item['nights'], 
        $item['rooms'], 
        $item['adults'], 
        $item['kids'], 
        $item['totalPrice']
    );

    if (!$stmt->execute()) {
        echo json_encode(['success' => false, 'message' => 'Error inserting booking: ' . $stmt->error]);
        exit();
    }
}

// If all inserts are successful
echo json_encode(['success' => true, 'message' => 'Booking confirmed!']);

$stmt->close();
$conn->close();
?>
