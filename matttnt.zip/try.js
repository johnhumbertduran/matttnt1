document.addEventListener('DOMContentLoaded', function () {
    // Unified function to update cart items for hotel, meals, ferry, and tours
    function updateCartItems(itemType, itemDetails) {
        let storedCart = JSON.parse(localStorage.getItem('cartItems')) || [];
        storedCart.push({ type: itemType, details: itemDetails });
        localStorage.setItem('cartItems', JSON.stringify(storedCart));
        displayCartItem(itemType, itemDetails);
    }

    // Confirm hotel room booking and add to cart
    document.getElementById('confirmDate').addEventListener('click', function () {
        const productId = this.getAttribute('data-product-id');
        const checkInDate = document.getElementById('modalCheckInDate').value;
        const checkOutDate = document.getElementById('modalCheckOutDate').value;
        const roomsCount = parseInt(document.getElementById('roomsCount').value);
        const adultsCount = parseInt(document.getElementById('adultsCount').value);
        const kidsCount = parseInt(document.getElementById('kidsCount').value);
        const productElement = document.querySelector(`.add-to-cart[data-product-id="${productId}"]`);
        const productName = productElement.getAttribute('data-product-name');
        const productImage = productElement.getAttribute('data-product-image');
        const priceAdult = parseFloat(productElement.getAttribute('data-price-2d1n-adult'));
        const priceKid = parseFloat(productElement.getAttribute('data-price-2d1n-kid'));
        const totalPriceAdults = priceAdult * adultsCount;
        const totalPriceKids = priceKid * kidsCount;
        const totalPrice = totalPriceAdults + totalPriceKids;

        const itemDetails = { productId, productName, productImage, checkInDate, checkOutDate, roomsCount, adultsCount, kidsCount, totalPrice };
        updateCartItems('hotel', itemDetails);
    });

    // Confirm meal booking and add to cart
    document.getElementById('confirmMealAddToCart').addEventListener('click', function () {
        const mealId = this.getAttribute('data-meal-id');
        const mealName = this.getAttribute('data-meal-name');
        const mealPrice = parseFloat(this.getAttribute('data-meal-price'));
        const mealQuantity = parseInt(document.getElementById('mealQuantityModal').value);
        const mealImage = this.getAttribute('data-meal-image');
        const totalPrice = mealPrice * mealQuantity;

        const itemDetails = { mealId, mealName, mealPrice, mealQuantity, mealImage, totalPrice };
        updateCartItems('meal', itemDetails);

        const mealModal = bootstrap.Modal.getInstance(document.getElementById('mealModal'));
        mealModal.hide();
    });

    // Confirm ferry booking and add to cart
    document.getElementById('addToCartBtn').addEventListener('click', function () {
        const ferryDate = document.getElementById('ferryDate').value;
        const ferrySchedule = document.getElementById('ferrySchedule').value;
        const ferryClass = document.getElementById('ferryClass').value;
        const adultQty = parseInt(document.getElementById('adultQuantity').value);
        const seniorQty = parseInt(document.getElementById('seniorQuantity').value);
        const kidQty = parseInt(document.getElementById('kidQuantity').value);
        const toddlerQty = parseInt(document.getElementById('toddlerQuantity').value);
        const adultPrice = parseFloat(document.getElementById('adultPrice').textContent.replace('₱', ''));
        const seniorPrice = parseFloat(document.getElementById('seniorPrice').textContent.replace('₱', ''));
        const kidPrice = parseFloat(document.getElementById('kidPrice').textContent.replace('₱', ''));
        const toddlerPrice = parseFloat(document.getElementById('toddlerPrice').textContent.replace('₱', ''));
        const totalPrice = (adultQty * adultPrice) + (seniorQty * seniorPrice) + (kidQty * kidPrice) + (toddlerQty * toddlerPrice);

        const itemDetails = { ferryDate, ferrySchedule, ferryClass, adultQty, seniorQty, kidQty, toddlerQty, totalPrice };
        updateCartItems('ferry', itemDetails);
    });

    // Confirm tour booking and add to cart
    document.querySelectorAll('.confirmAddToCart').forEach(function (button) {
        button.addEventListener('click', function () {
            const tourId = this.getAttribute('data-tour-id');
            const tourName = document.getElementById('tourName' + tourId).textContent;
            const priceAdult = parseFloat(document.getElementById('adultPrice' + tourId).textContent);
            const priceKid = parseFloat(document.getElementById('kidPrice' + tourId).textContent);
            const adultsCount = parseInt(document.getElementById('adultsCount' + tourId).value);
            const kidsCount = parseInt(document.getElementById('kidsCount' + tourId).value);
            const totalPriceAdults = priceAdult * adultsCount;
            const totalPriceKids = priceKid * kidsCount;
            const totalPrice = totalPriceAdults + totalPriceKids;

            const itemDetails = { tourId, tourName, adultsCount, kidsCount, totalPriceAdults, totalPriceKids, totalPrice };
            updateCartItems('tour', itemDetails);

            const modal = document.querySelector(`#addToCartModal${tourId}`);
            const modalInstance = bootstrap.Modal.getInstance(modal);
            modalInstance.hide();
        });
    });

    // Display items in the cart on the checkout page
    document.addEventListener('DOMContentLoaded', function () {
        const checkoutItemsContainer = document.getElementById('checkoutItems');
        const storedCart = JSON.parse(localStorage.getItem('cartItems')) || [];

        if (storedCart.length > 0) {
            storedCart.forEach(item => {
                if (item.type === 'hotel') displayHotelItem(item.details);
                if (item.type === 'meal') displayMealItem(item.details);
                if (item.type === 'ferry') displayFerryItem(item.details);
                if (item.type === 'tour') displayTourItem(item.details);
            });
        } else {
            checkoutItemsContainer.innerHTML = '<p>Your cart is empty.</p>';
        }
    });

    // Display functions for each category
    function displayHotelItem(hotel) {
        const newItem = document.createElement('li');
        newItem.classList.add('list-group-item');
        newItem.innerHTML = `
            <div class="d-flex align-items-center">
                <img src="${hotel.productImage}" alt="${hotel.productName}" class="cart-item-image me-3">
                <div>
                    <p class="mb-0"><strong>${hotel.productName}</strong></p>
                    <p class="mb-0">Check-In Date: ${hotel.checkInDate}</p>
                    <p class="mb-0">Check-Out Date: ${hotel.checkOutDate}</p>
                    <p class="mb-0">Rooms: ${hotel.roomsCount}</p>
                    <p class="mb-0">Adults: ${hotel.adultsCount}</p>
                    <p class="mb-0">Kids: ${hotel.kidsCount}</p>
                    <p class="mb-0"><strong>Total Price: ₱${hotel.totalPrice.toFixed(2)}</strong></p>
                </div>
            </div>
        `;
        document.getElementById('checkoutItems').appendChild(newItem);
    }

    function displayMealItem(meal) {
        const newItem = document.createElement('li');
        newItem.classList.add('list-group-item');
        newItem.innerHTML = `
            <div class="d-flex align-items-center">
                <img src="${meal.mealImage}" alt="${meal.mealName}" class="cart-item-image me-3">
                <div>
                    <p class="mb-0"><strong>${meal.mealName}</strong></p>
                    <p class="mb-0">Quantity: ${meal.mealQuantity}</p>
                    <p class="mb-0"><strong>Total Price: ₱${meal.totalPrice.toFixed(2)}</strong></p>
                </div>
            </div>
        `;
        document.getElementById('checkoutItems').appendChild(newItem);
    }

    function displayFerryItem(ferry) {
        const newItem = document.createElement('li');
        newItem.classList.add('list-group-item');
        newItem.innerHTML = `
            <div class="d-flex align-items-center">
                <div>
                    <p class="mb-0"><strong>Ferry ${ferry.ferryClass} Class</strong></p>
                    <p class="mb-0">Date: ${ferry.ferryDate}</p>
                    <p class="mb-0">Schedule: ${ferry.ferrySchedule}</p>
                    <p class="mb-0"><strong>Total Price: ₱${ferry.totalPrice.toFixed(2)}</strong></p>
                </div>
            </div>
        `;
        document.getElementById('checkoutItems').appendChild(newItem);
    }

    function displayTourItem(tour) {
        const newItem = document.createElement('li');
        newItem.classList.add('list-group-item');
        newItem.innerHTML = `
            <div class="d-flex align-items-center">
                <div>
                    <p class="mb-0"><strong>Tour: ${tour.tourName}</strong></p>
                    <p class="mb-0">Adults: ${tour.adultsCount} x ₱${tour.totalPriceAdults}</p>
                    <p class="mb-0">Kids: ${tour.kidsCount} x ₱${tour.totalPriceKids}</p>
                    <p class="mb-0"><strong>Total Price: ₱${tour.totalPrice.toFixed(2)}</strong></p>
                </div>
            </div>
        `;
        document.getElementById('checkoutItems').appendChild(newItem);
    }

    // Proceed to checkout
    document.getElementById('proceedToCheckout').addEventListener('click', function () {
        window.location.href = 'checkout.html';
    });

    // Clear cart after checkout
    function clearCart() {
        localStorage.removeItem('cartItems');
        document.getElementById('checkoutItems').innerHTML = '<p>Your cart is empty.</p>';
    }
});
