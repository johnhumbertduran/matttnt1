<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Check if the cart exists in the session
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    echo "<p>Your cart is empty. Please add items to the cart before proceeding to checkout.</p>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - Matt Travel and Tours</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Your Cart Items</h2>
    
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Product</th>
                <th>Check-In</th>
                <th>Check-Out</th>
                <th>Adults</th>
                <th>Kids</th>
                <th>Total Nights</th>
                <th>Total Price</th>
            </tr>
        </thead>
        <tbody>
        <?php
        // Display each item in the cart
        foreach ($_SESSION['cart'] as $cartItem) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($cartItem['product_name']) . "</td>";
            echo "<td>" . htmlspecialchars($cartItem['check_in_date']) . "</td>";
            echo "<td>" . htmlspecialchars($cartItem['check_out_date']) . "</td>";
            echo "<td>" . htmlspecialchars($cartItem['adults']) . "</td>";
            echo "<td>" . htmlspecialchars($cartItem['kids']) . "</td>";
            echo "<td>" . htmlspecialchars($cartItem['nights']) . "</td>";
            echo "<td>₱" . number_format($cartItem['price'] * $cartItem['nights'], 2) . "</td>";
            echo "</tr>";
        }
        ?>
        </tbody>
    </table>

    <!-- Proceed to Payment Button -->
    <a href="payment.php" class="btn btn-success">Proceed to Payment</a>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
