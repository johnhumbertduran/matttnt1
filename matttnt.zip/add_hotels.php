<?php
include 'db_connection.php'; // Include your database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['hotel_name'];
    $price_2d1n_adult = $_POST['price_2d1n_adult'];
    $price_2d1n_kid = $_POST['price_2d1n_kid'];
    $price_3d2n_adult = $_POST['price_3d2n_adult'];
    $price_3d2n_kid = $_POST['price_3d2n_kid'];
    $price_4d3n_adult = $_POST['price_4d3n_adult'];
    $price_4d3n_kid = $_POST['price_4d3n_kid'];
    $capacity = $_POST['capacity'];
    $inclusions = $_POST['inclusions'];
    $exclusions = $_POST['exclusions'];
    $policy = $_POST['policy'];
    $check_in = $_POST['check_in'];
    $check_out = $_POST['check_out'];
    $description = $_POST['description'];

    // Handle features as a comma-separated string
    if (isset($_POST['features'])) {
        $features = implode(', ', $_POST['features']);
    } else {
        $features = '';
    }

    // Handle multiple image uploads
    $target_dir = "images/";
    $image_urls = [];

    // Check if images are uploaded
    if (!empty($_FILES['hotel_images']['name'][0])) {
        foreach ($_FILES['hotel_images']['name'] as $key => $image_name) {
            $temp_name = $_FILES['hotel_images']['tmp_name'][$key];
            $image_name_unique = uniqid() . '-' . basename($image_name);
            $target_file = $target_dir . $image_name_unique;

            // Ensure the file is moved to the correct directory
            if (move_uploaded_file($temp_name, $target_file)) {
                $image_urls[] = $image_name_unique;
            } else {
                echo "Error uploading image $image_name. Continuing with other uploads...<br>";
            }
        }
    }

    // Convert the array of image names into a comma-separated string
    $image_urls_string = implode(', ', $image_urls);

    // Insert a new hotel record into the new table
    $query = "INSERT INTO hotel 
        (name, price_2d1n_adult, price_2d1n_kid, price_3d2n_adult, price_3d2n_kid, 
        price_4d3n_adult, price_4d3n_kid, capacity, inclusions, exclusions, policy, 
        features, check_in, check_out, description, image_urls) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }

    // Bind the parameters
    $stmt->bind_param(
        "sddddddssssssss",
        $name, 
        $price_2d1n_adult, 
        $price_2d1n_kid, 
        $price_3d2n_adult, 
        $price_3d2n_kid,
        $price_4d3n_adult, 
        $price_4d3n_kid, 
        $capacity, 
        $inclusions, 
        $exclusions, 
        $policy,
        $features, 
        $check_in, 
        $check_out, 
        $description, 
        $image_urls_string
    );

    // Execute the query
    if ($stmt->execute()) {
        header("Location: admin_dashboard.php"); // Redirect after successful insertion
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
}
?>
