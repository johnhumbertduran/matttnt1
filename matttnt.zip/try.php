<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Torn Paper Effect Example</title>
    <style>
        body, html {
            margin: 0;
            padding: 0;
            font-family: 'Roboto', sans-serif;
        }

        /* Torn paper effect container */
        .torn-paper {
            position: relative;
            width: 100%;
            height: 400px;
            background: url('/matttnt/images/beach/1.jpg') no-repeat center top;
            background-size: cover;
        }

        .torn-paper h1 {
            font-family: 'Montserrat', sans-serif;
            color: white;
            font-size: 4rem;
            text-align: center;
            margin-top: 100px;
        }

        /* Tear effect on the bottom */
        .torn-paper:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 50px;
            background: url('tear-bottom-effect.png') no-repeat center bottom;
            background-size: cover;
        }
    </style>
</head>
<body>

    <div class="torn-paper">
        <h1>Puerto Galera</h1>
    </div>

</body>
</html>
