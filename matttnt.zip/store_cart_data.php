<?php
session_start();

// Get the JSON data sent from the client
$input = json_decode(file_get_contents('php://input'), true);

if (isset($input['cartSummary']) && isset($input['totalAmount'])) {
    // Store cart summary and total amount in session
    $_SESSION['cartSummary'] = $input['cartSummary'];
    $_SESSION['totalAmount'] = $input['totalAmount'];

    // Debugging: Output session data to make sure it's set
    echo json_encode(['success' => true, 'session' => $_SESSION]);
} else {
    // Respond with error
    echo json_encode(['success' => false, 'message' => 'Invalid data']);
}
