<?php
session_start();

// Fetch the cart data from the session
$cartSummary = isset($_SESSION['cartSummary']) ? $_SESSION['cartSummary'] : [];
$totalAmount = isset($_SESSION['totalAmount']) ? $_SESSION['totalAmount'] : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proceed to Payment</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Order Summary</h1>
        <div class="row">
            <div class="col-md-8">
                <!-- Display Cart Summary -->
                <div class="card">
                    <div class="card-body">
                        <h5>Items:</h5>
                        <?php if (!empty($cartSummary)): ?>
                            <?php foreach ($cartSummary as $item): ?>
                                <div>
                                    <p><strong>Product:</strong> <?= htmlspecialchars($item['productName']) ?></p>
                                    <?php if (isset($item['checkInDate'])): ?>
                                        <p><strong>Check-In:</strong> <?= htmlspecialchars($item['checkInDate']) ?></p>
                                        <p><strong>Check-Out:</strong> <?= htmlspecialchars($item['checkOutDate']) ?></p>
                                        <p><strong>Nights:</strong> <?= htmlspecialchars($item['nights']) ?></p>
                                        <p><strong>Rooms:</strong> <?= htmlspecialchars($item['rooms']) ?></p>
                                        <p><strong>Adults:</strong> <?= htmlspecialchars($item['adults']) ?></p>
                                        <p><strong>Kids:</strong> <?= htmlspecialchars($item['kids']) ?></p>
                                    <?php elseif (isset($item['date'])): ?>
                                        <p><strong>Date:</strong> <?= htmlspecialchars($item['date']) ?></p>
                                        <p><strong>Schedule:</strong> <?= htmlspecialchars($item['schedule']) ?></p>
                                        <p><strong>Adults:</strong> <?= htmlspecialchars($item['adults']) ?></p>
                                        <p><strong>Seniors:</strong> <?= htmlspecialchars($item['seniors']) ?></p>
                                        <p><strong>Kids:</strong> <?= htmlspecialchars($item['kids']) ?></p>
                                    <?php elseif (isset($item['quantity'])): ?>
                                        <p><strong>Quantity:</strong> <?= htmlspecialchars($item['quantity']) ?></p>
                                    <?php endif; ?>
                                    <p><strong>Total Price:</strong> ₱<?= number_format($item['totalPrice'], 2) ?></p>
                                    <hr>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p>No items in the cart.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <!-- Total Summary -->
                <div class="card">
                    <div class="card-body">
                        <h5>Total Amount: ₱<?= number_format($totalAmount, 2) ?></h5>
                        <form action="process_payment.php" method="post">
                            <button type="submit" class="btn btn-primary w-100 mt-3">Proceed to Payment</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
