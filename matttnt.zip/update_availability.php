<?php
include 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $hotel_id = $_POST['hotel_id'];
    $dates = $_POST['dates'];  // Array of selected dates

    // Prepare the statements
    $check_sql = "SELECT * FROM hotel_availability WHERE hotel_id = ? AND date = ?";
    $update_sql = "UPDATE hotel_availability SET fully_booked = 1 WHERE hotel_id = ? AND date = ?";
    $insert_sql = "INSERT INTO hotel_availability (hotel_id, date, fully_booked) VALUES (?, ?, 1)";

    $check_stmt = $conn->prepare($check_sql);
    $update_stmt = $conn->prepare($update_sql);
    $insert_stmt = $conn->prepare($insert_sql);

    foreach ($dates as $date) {
        // Check if the date already exists for this hotel
        $check_stmt->bind_param('is', $hotel_id, $date);
        $check_stmt->execute();
        $result = $check_stmt->get_result();

        if ($result->num_rows > 0) {
            // If the date exists, mark it as fully booked
            $update_stmt->bind_param('is', $hotel_id, $date);
            $update_stmt->execute();
        } else {
            // Insert a new entry marking the date as fully booked
            $insert_stmt->bind_param('is', $hotel_id, $date);
            $insert_stmt->execute();
        }
    }

    // Close the prepared statements
    $check_stmt->close();
    $update_stmt->close();
    $insert_stmt->close();

    // Respond back
    echo json_encode(['success' => 'Fully booked dates updated']);
    exit();
}
